package ficha4.source;

public class SharedObj {
    private int number;
    private String name;

    public String getName() {return name;}
    public int getNumber() {return number;}

    public void setName(String n) {name=n;}

    public void setNumber(int n) {number=n;}

    
}
